
if (['celery','carrots','bread','milk']==['celery','carrots','bread','celery']):
    print "Both the arrays are the same"
else:
    print "Both the arrays are not the same"
