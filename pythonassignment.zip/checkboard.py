stringone = "* * * *"
stringtwo = " * * * *"

for count in range(1,9,1):
    if (count%2==1):
        print stringone
    elif (count%2==0):
        print stringtwo
