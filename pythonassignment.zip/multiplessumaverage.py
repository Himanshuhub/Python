for count in range(1,1001,2):
    print count
for countfives in range(5,1000001,5):
    print countfives
a = [1, 2, 5, 10, 255, 3]
print sum(a)
my_sum = sum(a)
my_avg = my_sum/len(a)
print my_avg
